package com.example.petcircle_proyectopsm

data class Post( val title: String,  val category: String, val date: String, val hour: String, val body: String, val imageUrl: String)